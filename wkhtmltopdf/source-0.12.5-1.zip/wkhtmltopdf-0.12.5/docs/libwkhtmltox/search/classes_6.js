var searchData=
[
  ['size',['Size',['../structwkhtmltopdf_1_1settings_1_1Size.html',1,'wkhtmltopdf::settings']]]
];
