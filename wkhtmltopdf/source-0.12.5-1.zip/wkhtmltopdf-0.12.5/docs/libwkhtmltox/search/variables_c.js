var searchData=
[
  ['screenheight',['screenHeight',['../structwkhtmltopdf_1_1settings_1_1ImageGlobal.html#a82868dfbcdaec2410c800c9228de6123',1,'wkhtmltopdf::settings::ImageGlobal']]],
  ['screenwidth',['screenWidth',['../structwkhtmltopdf_1_1settings_1_1ImageGlobal.html#abc5f83ea06d4524a76cc1c29f64a4c0e',1,'wkhtmltopdf::settings::ImageGlobal']]],
  ['size',['size',['../structwkhtmltopdf_1_1settings_1_1PdfGlobal.html#aeea9003f7853aade329e514b8ad8ab0b',1,'wkhtmltopdf::settings::PdfGlobal']]],
  ['spacing',['spacing',['../structwkhtmltopdf_1_1settings_1_1HeaderFooter.html#a19033dd004f2de54fdd0f7bb40a81072',1,'wkhtmltopdf::settings::HeaderFooter']]]
];
